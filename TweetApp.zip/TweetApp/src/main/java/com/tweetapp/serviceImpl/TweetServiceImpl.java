package com.tweetapp.serviceImpl;

import java.sql.Connection;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.mysql.cj.jdbc.MysqlDataSource;
import com.tweetapp.dao.TweetDAO;
import com.tweetapp.model.TweetEntity;
import com.tweetapp.util.DBUtils;
import com.tweetapp.util.TweetConstants;

public class TweetServiceImpl implements TweetDAO {

	public static Logger log = LogManager.getLogger(TweetServiceImpl.class);

	private Connection conn;
	private PreparedStatement prest;
	private ResultSet result;
	MysqlDataSource datasrc = DBUtils.getDataSourceConnection();

	/**
	 * Method to postTweet
	 * 
	 * @param tweetObj
	 * @return String
	 */
	public String postTweet(TweetEntity tweetObj) throws SQLException {
		log.info("Entering postTweet method::::");
		int res = 0;
		String response = "";

		try {
			conn = datasrc.getConnection();
			prest = conn.prepareStatement(TweetConstants.POST_TWEET);
			prest.setString(1, tweetObj.getEmailId());
			prest.setString(2, tweetObj.getTweetMessage());
			res = prest.executeUpdate();
			response = (res > 0) ? "Tweet Posted Successfully..." : "Tweet Unsuccessful...";
		} finally {
			closeConnection();
		}
		log.info("Exiting postTweet method::::\n");
		return response;
	}

	/**
	 * Method to fetchTweets
	 * 
	 * @param emailId
	 * @return List<TweetEntity>
	 */
	public List<TweetEntity> fetchTweets(String emailId) throws SQLException {
		log.info("Entering fetchTweets method::::");
		List<TweetEntity> response = new ArrayList<TweetEntity>();
		try {
			conn = datasrc.getConnection();
			prest = conn.prepareStatement(TweetConstants.VIEW_USER_TWEETS);
			prest.setString(1, emailId);
			result = prest.executeQuery();
			while (result.next()) {
				TweetEntity tweetObj = new TweetEntity();
				tweetObj.setTweetMessage(result.getString("tweet"));
				tweetObj.setPostedDate(result.getString("posted_on"));
				response.add(tweetObj);
			}
		} catch (Exception ex) {
			response = null;
			System.out.println(ex.getMessage());
		} finally {
			closeConnection();
		}
		log.info("Exiting fetchTweets method::::\n");
		return response;
	}

	/**
	 * Method to fetchAllTweets
	 * 
	 * @return List<TweetEntity>
	 */
	public List<TweetEntity> fetchAllTweets() throws SQLException {
		log.info("Entering fetchAllTweets method::::");
		List<TweetEntity> response = new ArrayList<TweetEntity>();
		try {
			conn = datasrc.getConnection();
			prest = conn.prepareStatement(TweetConstants.VIEW_ALLUSER_TWEETS);
			result = prest.executeQuery();
			while (result.next()) {
				TweetEntity tweetObj = new TweetEntity();
				tweetObj.setEmailId(result.getString("email"));
				tweetObj.setTweetMessage(result.getString("tweet"));
				tweetObj.setPostedDate(result.getString("posted_on"));
				response.add(tweetObj);
			}
		} catch (Exception ex) {
			response = null;
			System.out.println(ex.getMessage());
		} finally {
			closeConnection();
		}
		log.info("Exiting fetchAllTweets method::::\n");
		return response;
	}

	/**
	 * Method to closeConnection
	 */
	public void closeConnection() throws SQLException {
		if (conn != null) {
			conn.close();
		}
		if (result != null) {
			result.close();
		}
		if (prest != null) {
			prest.close();
		}
	}
}
