package com.tweetapp.serviceImpl;

import java.sql.Connection;
import java.sql.Date;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.List;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.mysql.cj.jdbc.MysqlDataSource;
import com.tweetapp.dao.UserDAO;
import com.tweetapp.model.UserEntity;
import com.tweetapp.util.DBUtils;
import com.tweetapp.util.TweetConstants;

public class UserServiceImpl implements UserDAO {

	public static Logger log = LogManager.getLogger(UserServiceImpl.class);

	private Connection conn;
	private PreparedStatement prest;
	private ResultSet result;

	MysqlDataSource datasrc = DBUtils.getDataSourceConnection();

	/**
	 * Method to addUser
	 * 
	 * @param userObj
	 * @return boolean
	 */
	public boolean addUser(UserEntity userObj) throws SQLException {
		log.info("Entering addUser method::::");
		if (!existingEmailID(userObj.getEmailId())) {
			java.sql.Date sqlDate = null;
			if (userObj.getDob() != null) {
				sqlDate = new Date(userObj.getDob().getTime());
			}
			int res = 0;
			try {
				conn = datasrc.getConnection();
				prest = conn.prepareStatement(TweetConstants.INSERT_USER);
				prest.setString(1, userObj.getFirstName());
				prest.setString(2, userObj.getLastName());
				prest.setString(3, userObj.getGender());
				prest.setDate(4, sqlDate);
				prest.setString(5, userObj.getEmailId());
				prest.setString(6, userObj.getUserPassword());
				res = prest.executeUpdate();
				if (res > 0) {
					return true;
				}
			} finally {
				closeConnection();
			}
		}
		log.info("Exiting addUser method::::\n");
		return false;
	}

	/**
	 * Method to existingEmailID
	 * 
	 * @param emailId
	 * @return boolean
	 */
	public boolean existingEmailID(String emailId) throws SQLException {
		log.info("Entering existingEmailID method::::");

		conn = datasrc.getConnection();
		prest = conn.prepareStatement(TweetConstants.CHECK_EMAIL);
		prest.setString(1, emailId);
		result = prest.executeQuery();
		if (result.next())
			return result.getInt("flag") == 1 ? true : false;

		log.info("Exiting existingEmailID method::::");
		return false;
	}

	/**
	 * Method to validateUser
	 * 
	 * @param emailId
	 * @param password
	 * @return boolean
	 */
	public String validateUser(String emailId, String password) throws SQLException {
		log.info("Entering validateUser method::::");
		String userPassword = "", firstName = "";
		String response = "";
		try {
			conn = datasrc.getConnection();
			if (!existingEmailID(emailId)) {
				response = "User does not exist!!!... Please Register and Try again\n";
				return response;
			} else {
				prest = conn.prepareStatement(TweetConstants.CHECK_USERPASSWORD);
				prest.setString(1, emailId);
				result = prest.executeQuery();
				if (result.next()) {
					userPassword = result.getString("userpassword");
					firstName = result.getString("first_name");
				}
				if (!password.equalsIgnoreCase(userPassword)) {
					response = "Invalid Credentials... Login Failed...\n";
					return response;
				} else {
					response = "Success " + firstName;
				}
			}
		} finally {
			closeConnection();
		}
		log.info("Exiting validateUser method::::");
		return response;
	}

	/**
	 * Method to changePassword
	 * 
	 * @param emailId
	 * @param reenter
	 * @return boolean
	 */
	public boolean changePassword(String emailId, String reenter) throws SQLException {
		log.info("Entering changePassword method::::");
		int update = 0;
		try {
			conn = datasrc.getConnection();
			prest = conn.prepareStatement(TweetConstants.UPDATE_PASSWORD);
			prest.setString(1, reenter);
			prest.setString(2, emailId);
			update = prest.executeUpdate();
			if (update > 0) {
				return true;
			}

		} finally {
			closeConnection();
		}
		log.info("Exiting changePassword method::::");
		return false;
	}

	/**
	 * Method to fetchAllUsers
	 * 
	 * @return List<UserEntity>
	 */
	public List<UserEntity> fetchAllUsers() throws SQLException {
		log.info("Entering fetchAllUsers method::::");
		List<UserEntity> response = new ArrayList<UserEntity>();
		try {
			conn = datasrc.getConnection();
			prest = conn.prepareStatement(TweetConstants.VIEW_ALL_USERS);
			result = prest.executeQuery();
			while (result.next()) {
				UserEntity userObj = new UserEntity();
				userObj.setEmailId(result.getString("email"));
				response.add(userObj);
			}
		} catch (Exception ex) {
			response = null;
			System.out.println(ex.getMessage());
			log.error(ex.getMessage());
		} finally {
			closeConnection();
		}
		log.info("Exiting fetchAllUsers method::::\n");
		return response;
	}

	/**
	 * Method to closeConnection
	 */
	public void closeConnection() throws SQLException {
		if (conn != null) {
			conn.close();
		}
		if (result != null) {
			result.close();
		}
		if (prest != null) {
			prest.close();
		}
	}

}
