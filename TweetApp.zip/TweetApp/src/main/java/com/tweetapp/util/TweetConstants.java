package com.tweetapp.util;

public class TweetConstants {

	public static final String EMAIL_REGEX = "^[a-zA-Z0-9+_.-]+@[a-zA-Z0-9.-]+\\.[a-zA-Z]{2,6}$";

	public static final String PASSWORD_REGEX = "^(?=.*[0-9])(?=.*[a-z])(?=.*[A-Z])(?=.*[!@#$%^&*])[a-zA-Z0-9!@#$%^&*](?=\\S+$).{8,15}";

	public static final String INSERT_USER = "INSERT INTO `tweetapp`.`user` (`first_name`, `last_name`, `gender`, `dob`, `email`, `userpassword`) VALUES(?, ?, ?, ?, ?, ?)";

	public static final String CHECK_EMAIL = "SELECT EXISTS(SELECT * FROM `tweetapp`.`user` WHERE lower(email) = lower(?)) AS flag";

	public static final String CHECK_USERPASSWORD = "SELECT first_name, userpassword FROM `tweetapp`.`user` where email = ?";

	public static final String UPDATE_PASSWORD = "UPDATE `tweetapp`.`user` SET userpassword = ? where lower(email) = lower(?)";

	public static final String POST_TWEET = "INSERT INTO `tweetapp`.`tweet` (`email`, `tweet`) VALUES (?, ?)";

	public static final String VIEW_USER_TWEETS = "SELECT tweet, posted_on FROM `tweetapp`.`tweet` where email = ?";

	public static final String VIEW_ALLUSER_TWEETS = "SELECT email, tweet, posted_on FROM `tweetapp`.`tweet`";

	public static final String VIEW_ALL_USERS = "SELECT email FROM `tweetapp`.`user`";

}
