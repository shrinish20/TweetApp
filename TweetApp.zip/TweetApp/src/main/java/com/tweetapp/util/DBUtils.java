package com.tweetapp.util;

import java.io.IOException;
import java.util.Properties;

import org.apache.log4j.LogManager;
import org.apache.log4j.Logger;

import com.mysql.cj.jdbc.MysqlDataSource;

public class DBUtils {

	public static Logger log = LogManager.getLogger(DBUtils.class);

	public static final String DATABASE_URL = "mysql.url";
	public static final String DATABASE_USERNAME = "mysql.username";
	public static final String DATABASE_PASSWORD = "mysql.password";

	public static Properties properties = new Properties();

	/**
	 * getDataSourceConnection Method
	 * 
	 * @return
	 */
	public static MysqlDataSource getDataSourceConnection() {
		MysqlDataSource datasource = new MysqlDataSource();
		try {
			log.info("Loading DB properties from properties file");
			properties.load(new java.io.FileInputStream("src/main/resources/db.properties"));
			datasource.setURL(properties.getProperty(DATABASE_URL));
			datasource.setUser(properties.getProperty(DATABASE_USERNAME));
			datasource.setPassword(properties.getProperty(DATABASE_PASSWORD));
		} catch (IOException e) {
			log.info("Unable to establish a Database Connection...");
			log.error("Exception found while loading properties" + e.getMessage());
		}
		return datasource;
	}
}
