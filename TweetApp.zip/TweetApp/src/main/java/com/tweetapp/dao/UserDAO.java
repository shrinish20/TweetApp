package com.tweetapp.dao;

import java.sql.SQLException;
import java.util.List;
import com.tweetapp.model.UserEntity;

public interface UserDAO {

	boolean addUser(UserEntity userObj) throws SQLException;

	String validateUser(String emailId, String password) throws SQLException;

	boolean existingEmailID(String emailId) throws SQLException;

	boolean changePassword(String emailId, String reenter) throws SQLException;

	List<UserEntity> fetchAllUsers() throws SQLException;

}
