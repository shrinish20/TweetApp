package com.tweetapp.dao;

import java.sql.SQLException;
import java.util.List;

import com.tweetapp.model.TweetEntity;

public interface TweetDAO {

	String postTweet(TweetEntity tweetObj) throws SQLException;

	List<TweetEntity> fetchTweets(String emailId) throws SQLException;

	List<TweetEntity> fetchAllTweets() throws SQLException;

}
