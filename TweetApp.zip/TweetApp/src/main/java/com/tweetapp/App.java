package com.tweetapp;

import java.io.BufferedReader;
import java.io.IOException;
import java.io.InputStreamReader;
import java.sql.SQLException;
import java.text.ParseException;
import java.text.SimpleDateFormat;
import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.regex.Matcher;
import java.util.regex.Pattern;

import com.tweetapp.dao.TweetDAO;
import com.tweetapp.dao.UserDAO;
import com.tweetapp.model.TweetEntity;
import com.tweetapp.model.UserEntity;
import com.tweetapp.serviceImpl.TweetServiceImpl;
import com.tweetapp.serviceImpl.UserServiceImpl;
import com.tweetapp.util.TweetConstants;

/**
 * Tweet App
 *
 */
public class App {
	static UserDAO userDao = new UserServiceImpl();
	static TweetDAO tweetDao = new TweetServiceImpl();
	static Pattern passwordPattern = Pattern.compile(TweetConstants.PASSWORD_REGEX, Pattern.CASE_INSENSITIVE);

	public static void main(String[] args) throws NumberFormatException {
		int menuOption;
		Date date = new Date();
		Pattern emailPattern = Pattern.compile(TweetConstants.EMAIL_REGEX, Pattern.CASE_INSENSITIVE);
		System.out.println("******** Tweet Application ********\n");
		System.out.println("Entering Tweet Applicaton......\n");
		try {
			BufferedReader inputStream = new BufferedReader(new InputStreamReader(System.in));
			String firstName = "", lastName = "", gender = "", dOb = "", emailId = "", password = "";
			while (true) {
				menuOption = nonLoggedInMenu();
				if (menuOption == 1) {

					UserEntity userObj = new UserEntity();
					System.out.println("Enter the Registration Details");
					System.out.println("First Name: ");
					firstName = inputStream.readLine();
					while (firstName.isEmpty()) {
						System.err.println("First Name is required....");
						firstName = inputStream.readLine();
					}
					System.out.println("Last Name: ");
					lastName = inputStream.readLine();
					System.out.println("Gender: ");
					gender = inputStream.readLine();
					while (gender.isEmpty()) {
						System.err.println("Gender is required....");
						gender = inputStream.readLine();
					}
					while (!("Male".equalsIgnoreCase(gender) || "Female".equalsIgnoreCase(gender)
							|| "Transgender".equalsIgnoreCase(gender))) {
						System.err.println("Please enter valid gender...");
						gender = inputStream.readLine();
					}
					System.out.println("Date Of Birth (dd-MM-yyyy): ");
					dOb = inputStream.readLine();
					try {
						date = new SimpleDateFormat("YYYY-MM-DD").parse(dOb);
					} catch (ParseException e) {
						e.printStackTrace();
					}
					System.out.println("EmailId: ");
					while (true) {
						emailId = inputStream.readLine();
						if (!validate(emailId, emailPattern)) {
							System.err.println("Email Address is not valid!... Please enter valid email address");
						} else {
							break;
						}
					}
					System.out.println("Password: ");
					while (true) {
						password = inputStream.readLine();
						if (!validate(password, passwordPattern)) {
							System.err.println(
									"Password should contain atleast one uppercase letter, one special character, one number.");
						} else {
							break;
						}
					}
					userObj.setFirstName(firstName);
					userObj.setLastName(lastName);
					userObj.setGender(gender);
					userObj.setDob(date);
					userObj.setEmailId(emailId);
					userObj.setUserPassword(password);
					boolean check = userDao.addUser(userObj);
					if (check) {
						System.out.println(firstName + " has been successfully added as a User. Try Logging In");

					} else {
						System.err.println("Registration Unsuccessful... User Already Exists...");
					}

				} else if (menuOption == 2) {

					System.out.println("Username: ");
					emailId = inputStream.readLine();
					System.out.println("Password: ");
					password = inputStream.readLine();
					String valid = userDao.validateUser(emailId, password);
					if (valid.contains("Success")) {
						System.out.println("Welcome " + valid.substring(8) + "\n");
						loggedInMenu(emailId, valid.substring(8));
					} else {
						System.err.println(valid);
					}

				} else if (menuOption == 3) {

					System.out.println("Enter Username: ");
					emailId = inputStream.readLine();
					if (!userDao.existingEmailID(emailId)) {
						System.err.println("User does not exist... Register to Continue");
					} else {
						resetMethod(emailId);
					}

				} else if (menuOption == 4) {
					System.out.println("Exiting Tweet Application......");
					System.exit(0);
				} else {
					System.err.println("Invalid option...");
					System.exit(0);
				}
				System.out.println();
			}
		} catch (SQLException sqlException) {
			System.out.println(sqlException.getMessage());
		} catch (IOException ioException) {
			System.out.println(ioException.getMessage());
		}
	}

	/**
	 * Reset Method
	 * 
	 * @param emailId
	 * @throws SQLException
	 */
	public static void resetMethod(String emailId) throws SQLException {
		String reenter = "", password = "";
		try {
			BufferedReader inputStream = new BufferedReader(new InputStreamReader(System.in));
			System.out.println("Re-set Password: ");
			while (true) {
				password = inputStream.readLine();
				if (!validate(password, passwordPattern)) {
					System.err.println(
							"Password should contain atleast one uppercase letter, one special character, one number.");
				} else {
					break;
				}
			}
			System.out.println("Confirm Password: ");
			while (true) {
				reenter = inputStream.readLine();
				if (!reenter.equals(password)) {
					System.err.println("Password Mismatch... Re-Enter Password Again....");
				} else {
					String message = (userDao.changePassword(emailId, reenter)) ? "\nPassword Changed Successfully..."
							: "\nPassword Change Unsuccessful.. Please try again...";
					System.out.println(message);
					break;
				}
			}
		} catch (IOException e) {
			System.out.println(e.getMessage());
		}
	}

	/**
	 * loggedInMenu Method
	 * 
	 * @param emailId
	 * @param name
	 * @throws NumberFormatException
	 * @throws IOException
	 * @throws SQLException
	 */
	private static void loggedInMenu(String emailId, String name)
			throws NumberFormatException, IOException, SQLException {
		int option;
		boolean logout = false;
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		while (true) {
			System.out.println("Choose any options below......\n");
			System.out.println("1. Post a tweet");
			System.out.println("2. View my tweets");
			System.out.println("3. View all tweets");
			System.out.println("4. View all Users");
			System.out.println("5. Reset Password");
			System.out.println("6. Logout\n");
			System.out.println("Enter your choice: ");
			option = Integer.parseInt(input.readLine());
			List<TweetEntity> tweetList = new ArrayList<TweetEntity>();
			List<UserEntity> userList = new ArrayList<UserEntity>();
			TweetEntity tweetObj = new TweetEntity();
			String tweetMsg = "", result = "";
			switch (option) {
			case 1:

				System.out.println("Enter the tweet ...");
				tweetMsg = input.readLine();
				tweetObj.setEmailId(emailId);
				tweetObj.setTweetMessage(tweetMsg);
				result = tweetDao.postTweet(tweetObj);
				System.out.println(result);
				break;

			case 2:

				System.out.println("Fetching your tweets...\n");
				tweetList = tweetDao.fetchTweets(emailId);
				if (tweetList != null) {
					tweetList.stream().forEach(tweets -> System.out
							.println(tweets.getTweetMessage() + "\nPosted On - " + tweets.getPostedDate() + "\n"));
				} else {
					System.out.println("No Tweets so far from " + name + "...");
				}
				break;

			case 3:

				System.out.println("Fetching all tweets...\n");
				tweetList = tweetDao.fetchAllTweets();
				if (tweetList != null) {
					tweetList.stream().forEach(tweets -> System.out.println(tweets.getTweetMessage() + "\nPosted By - "
							+ tweets.getEmailId() + "\nPosted On - " + tweets.getPostedDate() + "\n"));
				} else {
					System.out.println("No Tweets posted yet...");
				}
				break;

			case 4:

				System.out.println("Fetching all users...\n");
				userList = userDao.fetchAllUsers();
				if (userList != null) {
					userList.stream().forEach(users -> System.out.println(users.getEmailId()));
				} else {
					System.out.println("No Results Found...");
				}
				break;

			case 5:

				System.out.println("Password Resetting...");
				resetMethod(emailId);
				break;

			case 6:
				logout = true;
				System.out.println("Logged out Successfully");
				break;

			default:
				System.err.println("Invalid option...");
				input.close();
				System.exit(0);
				break;
			}
			if (logout) {
				break;
			}
			System.out.println();
		}
	}

	/**
	 * nonLoggedInMenu Method
	 * 
	 * @return
	 * @throws NumberFormatException
	 * @throws IOException
	 */
	public static int nonLoggedInMenu() throws NumberFormatException, IOException {
		int option;
		BufferedReader input = new BufferedReader(new InputStreamReader(System.in));
		System.out.println("To Continue Further, Choose any options below......\n");
		System.out.println("1. Register");
		System.out.println("2. Login");
		System.out.println("3. Forgot Password");
		System.out.println("4. Exit\n");
		System.out.println("Enter you choice: ");
		option = Integer.parseInt(input.readLine());
		return option;
	}

	/**
	 * validate Method
	 * 
	 * @param email
	 * @param pattern
	 * @return
	 */
	public static boolean validate(String email, Pattern pattern) {
		Matcher matcher = pattern.matcher(email);
		return matcher.find();
	}
}
