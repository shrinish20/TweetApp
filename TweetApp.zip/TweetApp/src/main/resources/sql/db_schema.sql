create database if not exists tweetapp;

create table if not exists tweetapp.user (
user_id int auto_increment,
first_name varchar(100) not null,
last_name varchar(100),
gender varchar(10) not null,
dob date not null,
email varchar(100) not null,
userpassword varchar(100) not null,
primary key (user_id),
unique (email)
);

create table if not exists tweetapp.tweet (
user_id int,
email varchar(100) not null,
tweet text,
posted_on timestamp default current_timestamp,
foreign key (user_id) references user(user_id)
);
